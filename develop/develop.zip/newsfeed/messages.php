<!DOCTYPE html>
<html>
<head>
	<title>Messages</title>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="messages.css">


 
</head>
<body> 

	<div align="centre">
		 
	<table>
		<tr>
			<th><h2>Sender</h2></th>
			<th><span class="center"> <h2>News Feed</h2></th>
		</tr>
 
	 

<?php 
	
// include "DB.php";

// $sql_statement = "SELECT * FROM messages";
// $result = mysqli_query($db, $sql_statement);

// while ($row = mysqli_fetch_assoc($result))
// {
// 	$mysender = $row['sender'];
// 	$message = $row['message'];

// 	echo "<tr>" . "<th>" . $mysender . "</th>" . "<th>" . $message . "</th>" . "</tr>";

// 	// echo $mysender . "<br>" . $message . "<br><br>";

// }


 ?>

 </table>

	</div>

</body>
</html>